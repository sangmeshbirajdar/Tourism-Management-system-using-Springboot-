package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class TouristDao implements TouristService 
{
	@Autowired
	TouristRepo tr;

	@Override
	public void register(Tourist t1)
	
	{
		tr.save(t1);

	}

	@Override
	public Tourist chkdata(String email, String password) {
		
		return tr.findByemailAndPassword(email, password);
	}

}
