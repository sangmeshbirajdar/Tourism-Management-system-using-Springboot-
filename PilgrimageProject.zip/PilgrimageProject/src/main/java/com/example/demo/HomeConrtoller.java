package com.example.demo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class HomeConrtoller
{
	@Autowired
	TouristService ts;

	@RequestMapping("/")
	public String one()
	{
		return "one";
	}
	@RequestMapping("/booknow")
	public String two()
	{
		return "booknow";
	}
	@RequestMapping("/payment")
	public String pay()
	{
		return "payment";
	}
	
	@RequestMapping("/packages")
	public String three()
	{
		return "packages";
	}
	
	@RequestMapping("/register")
	public String four()
	{
		return "register";
	}
	@RequestMapping("/login")
	public String log()
	{
		return "login";
	}
	
	@PostMapping("/next")
	public String getdata(@ModelAttribute("tt")Tourist tt)
	{
		ts.register(tt);
		return "redirect:/booknow";
	}

	@PostMapping("/CheckData")
	 public String check(@RequestParam("email") String email,@RequestParam("password") String password)
	 {
		
		Tourist t= ts.chkdata(email, password);
		if(t!=null)
		{
			return "redirect:/paymentpackage";
			
		}
		else
		{
		  return "redirect:/register";
		}
	 }
	@RequestMapping("/paymentpackage")
	public String thre()
	{
		return "paymentpackage";
	}
	
	

	
	

		
		
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/*@RequestMapping("/admin")
	public String admin()
	{
		return("admin");
	}
	
	@PostMapping("/adminlog")
	public String adminl(@RequestParam("username") String username,@RequestParam("password") String password)
	{
		if(username.equals("Sangmesh") && password.equals("Sangam@127"))
		{
			return"dashboard";
		}
		
		else 
		{
			return "admin";
		}
		
		
	}*/
	
}
