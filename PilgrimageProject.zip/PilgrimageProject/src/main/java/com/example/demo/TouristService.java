package com.example.demo;

public interface TouristService

{
	public void register(Tourist t1);


	  public Tourist chkdata(String email,String password);


}
